

package org.fi;
import org.fi.Context;


// *********************************************************************
// declare a new interface to add context
// *********************************************************************
public interface ClassWC { 

  public Context getContext();
  public void setContext(Context x);

};

