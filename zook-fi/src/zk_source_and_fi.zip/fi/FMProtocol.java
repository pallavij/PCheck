

// DEPRECATED .....

package org.fi;

import org.fi.*;
import org.fi.FMServer.FailType;




// public interface FMProtocol extends VersionedProtocol {
public interface FMProtocol {

  /*  
  public static final long versionID = 1L;
  
  // public boolean isInjectionEnabled(String fp);
  // public Command isInjectionEnabled(FailurePointDescriptor fp);

  public FailType sendContext(FMJoinPoint fjp, FMContext ctx, FMStackTrace st);


  // public void enableFailure();

  // public void disableFailure();
  
  public void sendFrogEvent(FMJoinPoint fjp, FMStackTrace fst, FrogEvent fv);

  */
}

